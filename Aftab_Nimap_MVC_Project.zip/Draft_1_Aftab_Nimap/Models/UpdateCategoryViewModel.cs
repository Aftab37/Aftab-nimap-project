﻿using System.ComponentModel.DataAnnotations;

namespace Draft_1_Aftab_Nimap.Models
{
    public class UpdateCategoryViewModel
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [StringLength(255)]
        public string CategoryName { get; set; }
    }
}
