﻿namespace Draft_1_Aftab_Nimap.Models
{
    public class AddCategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
