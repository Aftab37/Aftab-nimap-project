﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Draft_1_Aftab_Nimap.Models
{
    public class Product
    {
    [Key]
    public int ProductId { get; set; }

    [Required]
    [StringLength(255)]
    public string ProductName { get; set; }

    //public int CategoryId { get; set; }

    //[ForeignKey("CategoryId")]
    //public Category Category { get; set; }
    }
}
