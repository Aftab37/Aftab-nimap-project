﻿using System.ComponentModel.DataAnnotations;

namespace Draft_1_Aftab_Nimap.Models
{
    public class UpdateProductViewModel
    {
        [Key]
        public int ProductId { get; set; }

        [Required]
        [StringLength(255)]
        public string ProductName { get; set; }
    }
}
