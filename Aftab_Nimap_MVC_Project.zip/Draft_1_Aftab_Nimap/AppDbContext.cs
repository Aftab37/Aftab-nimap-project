﻿using Draft_1_Aftab_Nimap.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
namespace Draft_1_Aftab_Nimap
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}
