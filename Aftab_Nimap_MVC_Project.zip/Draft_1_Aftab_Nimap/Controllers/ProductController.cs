﻿using Draft_1_Aftab_Nimap.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Draft_1_Aftab_Nimap.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext dbproduct;

        public ProductController(AppDbContext dbproduct)
        {
            this.dbproduct = dbproduct;
        }

        //       [HttpGet]
        //       public async Task<IActionResult> Index()
        //       {
        //           var  Product = await dbproduct.Products.ToListAsync();
        //           return View(Product);
        //       }

        [HttpGet]
        public async Task<IActionResult> Index(int page = 1)
        {
            int pageSize = 10; 

            var totalProducts = await dbproduct.Products.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalProducts / pageSize);

        
            if (page < 1)
            {
                page = 1;
            }
            else if (page > totalPages)
            {
                page = totalPages;
            }

            var products = await dbproduct.Products
                .OrderBy(p => p.ProductId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;

            return View(products);
        }





        //-----------------------------------------------
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(AddProductViewModel addProductRequest)
        {
            var  product = new Product
            {
                // CategoryId = addCategoryRequest.Id,
                ProductName = addProductRequest.Name
            };
            dbproduct.Products.Add(product);
            dbproduct.SaveChanges();
            return RedirectToAction("Index");
        }

   ///------------------------------------------------------------

        [HttpGet]
        public async Task<IActionResult> view(int id)
        {
            var product = await dbproduct.Products.FirstOrDefaultAsync(x => x.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            if (product != null)
            {
                var viewModel = new UpdateProductViewModel
                {
                    ProductId = product.ProductId,         
                    ProductName = product.ProductName
                };
                return await Task.Run(() => View("View", viewModel));
            }
            return RedirectToAction("Index");
        }
   //-------------------------------------------------------

        [HttpPost]
        public async Task<IActionResult> view(UpdateProductViewModel model)
        {
            var product = await dbproduct.Products.FindAsync(model.ProductId);

            if (product != null)
            {
                product.ProductId = model.ProductId;
                product.ProductName = model.ProductName;

                await dbproduct.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");

        }

        //----------------------------------------------

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateProductViewModel model)
        {
            var product = await dbproduct.Products.FindAsync(model.ProductId);
            if (product != null)
            {
                dbproduct.Products.Remove(product);
                await dbproduct.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }
    }
}
