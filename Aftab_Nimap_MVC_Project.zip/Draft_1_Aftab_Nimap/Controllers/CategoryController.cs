﻿using Microsoft.AspNetCore.Mvc;
using Draft_1_Aftab_Nimap.Models;
using Microsoft.EntityFrameworkCore;

namespace Draft_1_Aftab_Nimap.Controllers
{
    public class CategoryController : Controller
    {
        private readonly AppDbContext dbContext;

        public CategoryController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        


        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var Category = await dbContext.Categories.ToListAsync();
            return View(Category);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(AddCategoryViewModel addCategoryRequest)
        {
            var category = new Category
            {
               // CategoryId = addCategoryRequest.Id,
                CategoryName = addCategoryRequest.Name
            };
            dbContext.Categories.Add(category);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> view(int id)
        {
            var category = await dbContext.Categories.FirstOrDefaultAsync(x => x.CategoryId == id);

            if (category == null)
            {
                return NotFound(); 
            }

            if (category != null)
            {
                var viewModel = new UpdateCategoryViewModel
                {
                    CategoryId = category.CategoryId,
                    CategoryName = category.CategoryName 
                };
                return await Task.Run(() => View("View", viewModel));
            }
            return RedirectToAction("Index"); 
        }

        [HttpPost]
        public async Task<IActionResult> view(UpdateCategoryViewModel model)
        {
            var category = await dbContext.Categories.FindAsync(model.CategoryId);
            
            if (category != null)
            {
                category.CategoryId = model.CategoryId;
                category.CategoryName = model.CategoryName;

                await dbContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
            
        }


        [HttpPost]
        public async Task<IActionResult> Delete(UpdateCategoryViewModel model)
        {
            var category = await dbContext.Categories.FindAsync(model.CategoryId);
            if (category != null)
            {
                dbContext.Categories.Remove(category);
                await dbContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }




    }

}
